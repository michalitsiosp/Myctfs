#!/usr/bin/env bash
random_num=$(( ($RANDOM % 100) +1))



if [ $# -eq 0 ]; then

echo -n  "Your task is to find the random number and submit it with this format wesis{nuber}"
echo ""
echo -n "Also i have a very wise question to ask you , what is your name?"
echo " "
read -r  name
echo " "
echo -e "$name . Dont panic , Organize"


echo ""
echo "             /------------------\       >  >   >  > >   >"
echo "        |\   /                   \    > >    >  >  >   >"
echo "        | \|      (o)             |      >  >  >   >    >   >"
echo "        | /|                      |       >   >   >   >  >  >"
echo "        |/   \\                  /         >    >     >  >  "
echo "              \\----------------/"
echo ""
echo ""
echo "                                         < < < < < < < < <"
echo "                                      < < < < < < < < < < < < < "
echo "             /------------------\\      < < < < < (o) < < < < < <"
echo "            /                    \\ / \   < < < < < < < < < < < < < <"
echo "           |     (O)               |/ |     < < < < < < < < < < < < < <==/|"
echo "           |                       |\ |     < < < < < < < < < < < < < <=\\|"
echo "            \\                    / \ /   < < < < < < < < < < < <"
echo "             \\------------------/      < < < < < < < < < < < <"
echo "                                      < < < < < < < < < < < <"
echo "                                        < < < < < < < < < < <"
echo ""
counter=1
echo -n " you will have to guess around 0-100 , maybe try binary search, Good Luck!"
echo ""
echo " +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo " ***************************************************************************"
echo " +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo ""      
flag="true"
while [ "$counter" -ne 8 ]; do
echo -n "guess the number: "
echo ""
read -r input
if [[ ! "$input" =~ ^[0-9]+$ ]]; then
    echo "Error: '$input' is not a valid positive integer. Try again!"
    continue
  fi
if [ $random_num -gt $input ]; then 
    echo "random > your_number"
  elif [ $random_num -lt $input ]; then 
     echo "random < your number "
  else 
   echo "So you know binary search ... ok i think you beat me, for now!"
   echo "created secret.txt in your directory"
   touch  secret.txt
   echo "finally you found the flag "
   echo  "" 
   echo "wesis{$random_num}" > secret.txt
   flag="false"
   break

fi
counter=$((counter+1))
done
if [ "$flag" = "true" ]; then 
echo "log2(100) = 7 , so you have only 7 tries"
echo "what are you waiting for try again!"
fi
fi
